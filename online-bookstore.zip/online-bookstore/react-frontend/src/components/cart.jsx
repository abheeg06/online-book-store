import axios from 'axios';
import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';

const Cart = () => {
	const [cart, setCart] = useState([]);
	const [price, setPrice] = useState(0);
	const [showNotification, toggleNotification] = useState(false);
	
	function getCart() {
		if (window.localStorage.getItem('isLoggedIn')) {
			axios.get(`/api/cart/${window.localStorage.getItem('userID')}`)
				.then((response) => {
					setCart([...response.data]);
				})
		}
		if (window.localStorage.getItem('cart')) {
			const cart = JSON.parse(window.localStorage.getItem('cart'));
			setCart(cart);
		}
	}

	useEffect(() => {
		getCart();
	}, [])

	function deleteFromCart(indexToDelete) {
		const newCart = cart.filter((cartItem, index) => index !== indexToDelete);
		if (!window.localStorage.getItem('isLoggedIn')) {
			window.localStorage.setItem('cart', JSON.stringify(newCart));
			setCart(newCart);
		}
		else {
			axios.patch(`/api/cart/add/${window.localStorage.getItem('userID')}`, newCart)
				.then((response) => setCart(response.data))
				.catch(error => console.log(error))
		}
	}

	useEffect(() => {
		const reducer = (acc, curr) => acc + parseInt(curr.quantity*curr.price);
		const total = cart.reduce(reducer, 0)
		setPrice(total);
	}, [cart])

	function showCart() {
		if (cart.length === 0) {
			return (<div className="alert alert-info mx-3 text-center">No items in cart</div>)
		}
		else {
			return (
				cart.map((cartItem, index) => (
					<div key={cartItem.bookID + index} className="list-group-item flex-column align-items-start">
						<div className="d-flex w-100 justify-content-between">
							<h5 className="mb-1">Book Name: {cartItem.bookName}</h5>
							<button className="btn btn-danger btn-sm" onClick={() => deleteFromCart(index)}>Delete</button>
						</div>
						<p className="mb-1">Quantity: {cartItem.quantity}</p>
					</div>
				))
			)
		}
	}

	function checkoutButton() {
		if (cart.length === 0) {
			return <Link to="/checkout" className="btn btn-warning btn-sm" onClick={(event) => {
				event.preventDefault();
				toggleNotification(true);
				setTimeout(() => {
					toggleNotification(false);
				}, 2000)
			}}>Checkout</Link>
		}
		else {
			return <Link to="/checkout" className="btn btn-warning btn-sm">Checkout</Link>
		}
	}

	function emptyCartNotification() {
		return (
			<div
				className="alert alert-danger text-center"
				style={{
						width: "300px",
						position: 'absolute', left: '50%', top: '100px',
						transform: 'translate(-50%, 0)',
						zIndex: "1000"
				}}
				>
				Cart is empty, cannot checkout!
			</div>
		)
	}

	return (
		<>
			{showNotification && emptyCartNotification()}
			<div className="ml-2 mb-4"><small><Link to="/">Home </Link>&gt; Cart</small></div>
			<div className="list-group">
				<h4 className="mb-4 ml-3">My Shopping Cart</h4>
				{showCart()}
			</div>
			<div className="row no-gutters justify-content-between mt-4">
				<h5 className="ml-3">Total Price: ${price}</h5>
				<span>
					<Link to="/" className="btn btn-secondary btn-sm mr-2">Back</Link>
					{checkoutButton()}
					
				</span>
			</div>
		</>
	)
}

export default Cart;