import React, { useEffect, useState } from 'react';
import { Link, useHistory } from 'react-router-dom';
import axios from 'axios';

const Checkout = () => {
	const [ cart, setCart ] = useState([]);
	const [ price, setPrice ] = useState(0);
	const [ username, setUsername ] = useState('');
	const [ password, setPassword ] = useState('');
	const [ errorMsg, setErrorMsg ] = useState('');
	const [ errorMsg2, setErrorMsg2 ] = useState('');
	const [ fullname, setFullName ] = useState('');
	const [ company, setCompany ] = useState('');
	const [ address1, setAddress1 ] = useState('');
	const [ address2, setAddress2 ] = useState('');
	const [ city, setCity ] = useState('');
	const [ region, setRegion ] = useState('');
	const [ country, setCountry ] = useState('');
	const [ postcode, setPostcode ] = useState('');
	const history = useHistory();

	function getCart() {
		if (window.localStorage.getItem('isLoggedIn')) {
			axios.get(`/api/cart/${window.localStorage.getItem('userID')}`)
				.then((response) => {
					setCart([...response.data]);
				})
		}
		if (window.localStorage.getItem('cart')) {
			const cart = JSON.parse(window.localStorage.getItem('cart'));
			setCart(cart);
		}
	}

	useEffect(() => {
		const reducer = (acc, curr) => acc + parseInt(curr.quantity*curr.price);
		const total = cart.reduce(reducer, 0)
		setPrice(total);
	}, [cart])

	useEffect(() => {
		getCart();
	}, [])
	
	function failNotification() {
		return (
			<div className="alert alert-danger text-center">
				{errorMsg}
			</div>
		)
	}

	function selectionForm() {
		return (
			<>
				<h4>Create account or <Link to="/login">Signin</Link> to checkout</h4>
			</>
		)
	}

	function handleSubmit() {
		if (!window.localStorage.getItem('isLoggedIn')) {
			if (username === '' || password === '') setErrorMsg("Fill in all fields!")
			const payload = { username, password }
			axios.post('/api/user/register', payload)
				.then(response => {
					if (username === response.data.username) {
						setErrorMsg('');
					}
					else {
						setErrorMsg(response.data.error);
					}
				})
				.catch(error => console.log(error))
		}

		if (fullname && address1 && city && country && postcode) {
			saveDetails();
			clearForm();
			history.push('/invoice');
		}
		else {
			setErrorMsg2('Fill in required fields');
		}
	}

	function saveDetails() {
		window.localStorage.setItem('fullname', fullname);
		company && window.localStorage.setItem('company', company);
		window.localStorage.setItem('address1', address1);
		address2 && window.localStorage.setItem('address2', address2);
		window.localStorage.setItem('city', city);
		region && window.localStorage.setItem('region', region);
		window.localStorage.setItem('country', country);
		window.localStorage.setItem('postcode', postcode);
	}

	function clearForm() {
		setUsername('');
		setPassword('');
		setErrorMsg('');
		setErrorMsg2('');
		setFullName('');
		setCompany('');
		setAddress1('');
		setAddress2('');
		setCity('');
		setRegion('');
		setCountry('');
		setPostcode('');
		return ''
	}

	function failNotification2() {
		return (
			<div className="alert alert-danger text-center">{errorMsg2}</div>
		)
	}

	function createAccountForm() {
		return (
			<>
				<div className="row mb-5">
					<div className="col">
						<div className="card">
							<div className="card-body">
								<h4>Create Account</h4>
								<div className="form-row">
									<div className="form-group col-md-6">
										<label>Username</label>
										<input type="text" value={username} className="form-control" onChange={(event) => setUsername(event.target.value)} placeholder="Username"/>
									</div>
									<div className="form-group col-md-6">
										<label>Password</label>
										<input type="password" value={password} className="form-control" onChange={(event) => setPassword(event.target.value)} placeholder="Password"/>
									</div>
									{errorMsg && failNotification()}
								</div>
							</div>
						</div>
					</div>
				</div>
			</>
		)
	}

	return (
		<>
			<div className="row mb-5">
				<div className="col">
					<div className="card">
						<div className="card-body">
							<p className="text-right">Your order: (<Link to="/cart">change</Link>)</p>
							<p className="font-weight-bold">Free Standard Shipping</p>
							{cart.map((cartItem, index) => (
								<div key={cartItem.bookID + index}>
									<div className="d-flex justify-content-between">
										<span>{cartItem.quantity} x {cartItem.bookName} </span>
										<span>${cartItem.price}</span>
									</div>
									<hr/>
								</div>
							))}
							<div className="d-flex justify-content-between">
								<span>Total</span>
								<span>${price}</span>
							</div>
						</div>
					</div>
				</div>
			</div>
			{!window.localStorage.getItem('isLoggedIn') ? selectionForm() : ''}
			{!window.localStorage.getItem('isLoggedIn') ? createAccountForm() : ''}
			<div className="row mb-5">
				<div className="col">
					<div className="card">
						<div className="card-body">
							<h4>Delivery Details</h4>
							{errorMsg2 && failNotification2()}
							<div className="form-row">
								<div className="form-group col-md-6">
									<label>Full Name</label>
									<input type="text" value={fullname} onChange={(event) => setFullName(event.target.value)} className="form-control" placeholder="Required"/>
								</div>
								<div className="form-group col-md-6">
									<label>Company</label>
									<input type="text" value={company} onChange={(event) => setCompany(event.target.value)} className="form-control"/>
								</div>
							</div>
							<div className="form-group">
								<label>Address 1</label>
								<input type="text" value={address1} onChange={(event) => setAddress1(event.target.value)} className="form-control" placeholder="Required"/>
							</div>
							<div className="form-group">
								<label>Address 2</label>
								<input type="text" value={address2} onChange={(event) => setAddress2(event.target.value)} className="form-control"/>
							</div>
							<div className="form-group">
								<label>Region/ State/ District</label>
								<input type="text" value={region} onChange={(event) => setRegion(event.target.value)} className="form-control"/>
							</div>
							<div className="form-row">
								<div className="form-group col-md-6">
									<label>City</label>
									<input type="text" value={city} onChange={(event) => setCity(event.target.value)} className="form-control" placeholder="Required"/>
								</div>
								<div className="form-group col-md-2">
									<label>Zip</label>
									<input type="text" value={postcode} onChange={(event) => setPostcode(event.target.value)} className="form-control" placeholder="Required"/>
								</div>
							</div>
							<div className="form-group">
								<label>Country</label>
								<input type="text" value={country} onChange={(event) => setCountry(event.target.value)} className="form-control" placeholder="Required"/>
							</div>
							<div className="text-right mt-3">
								<button type="submit" className="btn btn-primary" onClick={() => handleSubmit()}>Confirm</button>
							</div>
						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default Checkout;