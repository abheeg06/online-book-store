import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';

const BookShow = () => {
	const { book_id } = useParams();
	const [book, setBook] = useState({});
	const [ quantity, setQuantity ] = useState(1);
	const [ cart, setCart ] = useState([]);
	const [ success, setSuccess] = useState(false);

	function getBook() {
		axios.get(`/api/book/${book_id}`)
			.then(response => setBook(response.data))
			.catch(error => console.log(error))
	}

	function getCart() {
		if (window.localStorage.getItem('isLoggedIn')) {
			axios.get(`/api/cart/${window.localStorage.getItem('userID')}`)
				.then((response) => {
					setCart([...response.data]);
				})
		}
		if (window.localStorage.getItem('cart')) {
			const cart = JSON.parse(window.localStorage.getItem('cart'));
			setCart(cart);
		}
	}

	function handleQuantityChange(event) {
		setQuantity(event.target.value);
	}

	function showSuccess() {
		return (<div className="alert alert-success">Successfully added to cart.</div>)
	}

	function addToCart() {
		if (quantity > 0) {
			const newCart = [
				...cart,
				{
					bookID: book_id,
					quantity,
					bookName: book.bookName,
					price: book.price
				}
			]
			setCart(newCart);
			if (window.localStorage.getItem('isLoggedIn')) {
				axios.patch(`/api/cart/add/${window.localStorage.getItem('userID')}`, newCart)
					.then((cartItems) => setCart(cartItems))
					.catch(error => console.log(error))	
			}
			else {
				window.localStorage.setItem('cart', JSON.stringify(newCart));
			}
		}
		setSuccess(true);
		setTimeout(() => {
			setSuccess(false)
		}, 5000);
	}

	useEffect(() => {
		getBook();
		getCart();
	}, [])
	return (
		<>
			<div className="row">
				<div className="col">
					<div className="mb-2">
						<Link to="/">Home</Link> &gt; {book.bookName}
					</div>
					<div className="card">
						<div className="card-body">
							<h3 className="card-title">{book.bookName}</h3>
							{success ? showSuccess(): ''}
							<img src={`/assets/${book.imgPath}`} alt=""/>
							<dl className="row mb-4">
								<dt className="col-4">Author:</dt>
								<dd className="col-8">{book.author}</dd>
								<dt className="col-4">Publisher:</dt>
								<dd className="col-8">{book.publisher}</dd>
								<dt className="col-4">Category:</dt>
								<dd className="col-8">{book.category}</dd>
								<dt className="col-4">Language:</dt>
								<dd className="col-8">{book.language}</dd>
								<dt className="col-4">Description:</dt>
								<dd className="col-8">{book.description}</dd>
								<dt className="col-4">Price:</dt>
								<dd className="col-8">${book.price}</dd>		
							</dl>

							<div style={{position: 'absolute', bottom: '5px', right: '5px'}}>
								<input className="form-control-sm" type="number" value={quantity} onChange={(event) => handleQuantityChange(event)}/>
								<button className="btn btn-warning btn-sm ml-2" onClick={() => addToCart()}>Add to cart</button>
							</div>
							
						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default BookShow;