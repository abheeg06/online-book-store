import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

const BookStage = (props) => {
	const [categories, setCategories] = useState([]);
	const [books, setBooks] = useState([]);
	const [currentCategory, setCurrentCategory] = useState('');
	const [header, setHeader] = useState('All Books');

	function getCategories() {
		axios.get('/api/book/categories')
      .then((response) => {
				setCategories(response.data);
      })
      .catch((error) => {
        console.log(error);
      });
	}

	function filterCategory(category) {
		const params = { category }
		axios.get('/api/book/category', { params })
			.then(response => {
				setBooks(response.data);
			})
			.catch(error => console.log("Error querying books: " + error));
		setCurrentCategory(category);
		setHeader(category);
	}

	function getBooks(searchKeywords) {
		const params = { query : searchKeywords }
		if (searchKeywords !== '') {
			setHeader('Search results');
		}
		axios.get('/api/book', { params })
			.then(response => {
				if (response.data.error) {
					setBooks([]);
				}
				else {
					setBooks(response.data);
				}
			})
			.catch(error => console.log(error));
	}

	function handleClickHome() {
		setHeader('All Books');
		setCurrentCategory('');
		getBooks('');
	}

	function handleSortByPrice() {
		let newBooks = books;
		for (let i = 0; i < newBooks.length; i++) {
			for (let j = 0; j < newBooks.length - i - 1; j++) {
					if (newBooks[j + 1].price > newBooks[j].price) {
							[newBooks[j + 1], newBooks[j]] = [newBooks[j], newBooks[j + 1]];
					}
			}
		}
		setBooks([...newBooks]);
		if (!header.includes('(Sorted By Highest Price)')) {
			setHeader(header +' (Sorted By Highest Price)')
		}
	}
	
	useEffect(() => {
		getCategories();
		setHeader('All Books');
	}, [])


	useEffect(() => {
		getBooks(props.searchKeywords);
	}, [props.searchKeywords, props.changed])


	return (
		<>
			<div className="row">
				<div className="col-lg-3 mb-4">
					<div className="list-group">
						{categories.map((category, index) => <div key={index} style={{cursor: 'pointer'}} className={`list-group-item list-group-item-action ${category === currentCategory ? 'active': ''}`} onClick={() => filterCategory(category)}>{category}</div>)}
					</div>
				</div>
				<div className="col-lg-9">
					<div className="d-flex justify-content-between">
						<small><Link to="/" onClick={() => handleClickHome()}>Home </Link> {currentCategory? "> " + currentCategory : ''}</small>
						<span style={{cursor: 'pointer'}} onClick={() => handleSortByPrice()} className="badge badge-primary">Sort by price(Highest)</span>
					</div>
					<h3 className="text-center my-4">{header}</h3>
					<div className="row">
						{books.length !== 0 ? books.map((book) => { 
							return (
								<div key={book._id} className="col-sm-6 col-lg-4 mb-3">
									<div className="card" style={{height: '100%'}}>
										<img className="card-img-top" src={`/assets/${book.imgPath}`}/>
										<h3 className="position-absolute" style={{top: '5px', left: '5px'}}><span className="badge badge-primary">${book.price}</span></h3>
										<h4 className="position-absolute" style={{top: '5px', right: '5px'}}><span className="badge badge-warning">{book.newArrival && 'New Arrival'}</span></h4>
										<div className="card-body">
											<h4 className="card-title mb-5">{book.bookName}</h4>										
										</div>
										<div className="card-footer">
											<p className="card-text d-block" >Author: {book.author}</p>
											<p className="card-text d-block" >Publisher: {book.publisher}</p>	
										</div>
										<Link to={`/books/${book._id}`} className="card-footer text-center">
											See more
										</Link>
									</div>
								</div>
							);
						}) : (<div className="col"><h5>No results</h5></div>)	}
					</div>
				</div>
			</div>
		</>
	)
}

export default BookStage;