import React, { useState, useEffect } from 'react'
import { Route, Switch, useHistory } from 'react-router-dom';
import SearchBar from './searchbar';
import BookStage from './book-stage';
import BookShow from './book-show';
import Login from './login';
import Register from './register';
import Checkout from './checkout';
import Cart from './cart';
import Invoice from './invoice'
import axios from 'axios';

const Home = () => {
	const [ isLoggedIn, setLoggedIn ] = useState(false);
	const [ searchKeywords, setSearchKeywords ] = useState('');
	const [ changed, setChanged ] = useState(false);
	const [ showLogoutNotification , toggleLogoutNotification ] = useState(false);
	const history = useHistory();

	function login() {
		setLoggedIn(true);
		const cart = JSON.parse(window.localStorage.getItem('cart'));
		axios.patch(`/api/cart/add/${window.localStorage.getItem('userID')}`, cart)
			.then(() => window.localStorage.removeItem('cart'))
			.catch(error => console.log(error))
	}

	function signout() {
		setLoggedIn(false);
		toggleLogoutNotification(true);
		setTimeout(() => {
			history.push('/');
		}, 1000);
		setTimeout(() => {
			toggleLogoutNotification(false);
		}, 3000);
		window.localStorage.removeItem('username');
		window.localStorage.removeItem('isLoggedIn');
		window.localStorage.removeItem('userID');
	}

	function handleSearch(keywords) {
		history.push('/');
		setChanged(!changed);
		setSearchKeywords(keywords);
	}

	function logoutNotification() {
		return (
			<div
				className="alert alert-success text-center"
				style={{
						width: "300px",
						position: 'absolute', left: '50%', top: '50px',
						transform: 'translate(-50%, 0)',
						zIndex: "1000"
				}}
				>
				Logged out successfully.
			</div>
		)
	}

	useEffect(() => {
		if (window.localStorage.getItem('isLoggedIn')) {
			setLoggedIn(true);
		}
	}, [])


  return (
		<>
		{showLogoutNotification && logoutNotification()}
		<SearchBar isLoggedIn={isLoggedIn} signout={() => signout()} handleSearch={(event) => handleSearch(event)}/>
		<div className="container mt-5">
			<Switch>
				<Route path="/" exact render={() => (
					<BookStage searchKeywords={searchKeywords} changed={changed}/>
				)}/>
				<Route path="/books" exact render={() => (
					<BookStage searchKeywords={searchKeywords} changed={changed}/>
				)}/>
				<Route path="/books/:book_id" render={() => (
					<BookShow />
				)}></Route>
				<Route path="/login" render={() => (
    			<Login login={() => login()}/>
  			)}/>
				<Route path="/register" component={Register}></Route>
				<Route path="/cart" render={() => (
					<Cart />
				)}/>
				<Route path="/checkout" component={Checkout}></Route>
				<Route path="/invoice" render={() => (
					<Invoice signout={() => signout()}/>
				)}/>
			</Switch>	
		</div>
		
		</>
  )
}

export default Home;