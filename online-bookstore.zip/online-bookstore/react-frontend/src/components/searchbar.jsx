import React, { useState } from 'react';
import { Link } from 'react-router-dom';

const SearchBar = (props) => {
	const [ keywords, setKeywords ] = useState('');

	function handleSetKeywords(event) {
		setKeywords(event.target.value);
	}

	function nonLoggedInButtons() {
		return (
			<>
				<Link to="/login" className="btn btn-secondary mr-3">Sign in</Link>
				<Link to ="/register" className="btn btn-secondary mr-3">Register</Link>
			</>
		)
	}

	function loggedInButtons() {
		return (
			<>
				<button className="btn btn-secondary mr-3" onClick={() => props.signout()}>Sign Out</button>
			</>
		)
	}

	return (
		<>
			<nav className="navbar navbar-expand-lg navbar-light bg-light">
				<div className="container">
					<div className="form-inline my-2 my-lg-0">
						<input type="text" className="form-control" value={keywords} onChange={(event) => handleSetKeywords(event)} placeholder="Search book"/>
						<button className="btn btn-outline-primary rounded-lg ml-sm-3 mt-3 mt-sm-0" onClick={() => props.handleSearch(keywords)}>Search</button>
					</div>
					<div className="ml-md-auto ml-0">
							{props.isLoggedIn ? loggedInButtons() : nonLoggedInButtons()}
							<Link to="/cart" className="btn btn-warning">Cart</Link>
						</div>
				</div>
			</nav>
			<div className="container">
				<div className="d-flex">
				</div>
			</div>
		</>
	)
}

export default SearchBar;