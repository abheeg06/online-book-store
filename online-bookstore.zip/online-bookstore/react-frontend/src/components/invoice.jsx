import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useHistory } from 'react-router-dom';

const Invoice = (props) => {
	const [ price, setPrice ] = useState(0);
	const [ cart, setCart ] = useState([]);
	const history = useHistory();

	function getCart() {
		if (window.localStorage.getItem('isLoggedIn')) {
			axios.get(`/api/cart/${window.localStorage.getItem('userID')}`)
				.then((response) => {
					setCart([...response.data]);
				})
		}
		if (window.localStorage.getItem('cart')) {
			const cart = JSON.parse(window.localStorage.getItem('cart'));
			setCart(cart);
		}
	}

	async function handleFinish() {
		clearStorage();
		if (window.localStorage.getItem('isLoggedIn')) {
			await axios.delete(`/api/cart/delete/${window.localStorage.getItem('userID')}`, []);
		}
		else {
			window.localStorage.removeItem('cart');
		}
		props.signout();
		history.push('/');
	}

	function clearStorage() {
		window.localStorage.removeItem('fullname');
		window.localStorage.removeItem('company');
		window.localStorage.removeItem('address1');
		window.localStorage.removeItem('address2');
		window.localStorage.removeItem('city');
		window.localStorage.removeItem('region');
		window.localStorage.removeItem('country');
		window.localStorage.removeItem('postcode');
		return ''
	}

	useEffect(() => {
		const reducer = (acc, curr) => acc + parseInt(curr.quantity*curr.price);
		const total = cart.reduce(reducer, 0)
		setPrice(total);
	}, [cart])

	useEffect(() => {
		getCart();
	}, [])

	return (
		<>
			<div className="row">
				<div className="col">
					<div className="card">
						<div className="card-body">
						<div className="alert alert-success text-center">Thanks for ordering. Your books will be delivererd within 7 working days.</div>
							<h3>Invoice Page</h3>
							<dl className="row">
								<dt className="col-sm-3">Full Name: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('fullname')}</dd>
								<dt className="col-sm-3">Company: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('company') || 'NA'}</dd>
								<dt className="col-sm-3">Address Line 1: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('address1')}</dd>
								<dt className="col-sm-3">Address Line 2: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('address2') || 'NA'}</dd>
								<dt className="col-sm-3">City: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('city')}</dd>
								<dt className="col-sm-3">Region: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('region') || 'NA'}</dd>
								<dt className="col-sm-3">Country: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('country')}</dd>
								<dt className="col-sm-3">Postcode: </dt>
								<dd className="col-sm-9">{window.localStorage.getItem('postcode')}</dd>
							</dl>
							<div className="row">
								<div className="col text-right">
									<button onClick={() => handleFinish()} className="btn btn-primary">Finish</button>
								</div>	
							</div>	
						</div>
					</div>
				</div>
			</div>
			<div className="row my-5">
				<div className="col">
					<div className="card">
						<div className="card-body">
							{cart.map((cartItem, index) => (
								<div key={cartItem.bookID + index}>
									<div className="d-flex justify-content-between">
										<span>{cartItem.quantity} x {cartItem.bookName} </span>
										<span>${cartItem.price}</span>
									</div>
									<hr/>
								</div>
							))}
							<div className="d-flex justify-content-between">
								<span>Total</span>
								<span>${price}</span>
							</div>
						</div>
					</div>
				</div>
			</div>
		</>
	)
}

export default Invoice;