import axios from 'axios';
import React, { useState } from 'react';
import { Link, useHistory } from 'react-router-dom';

const Login = (props) => {
	const [ username, setUsername ] = useState('');
	const [ password, setPassword ] = useState('');
	const [ msg, setMsg ] = useState('');
	const [ errorMsg, setErrorMsg ] = useState('');
	const history = useHistory();

	function handleUsernameChange(event) {
		setUsername(event.target.value);
	}

	function handlePasswordChange(event) {
		setPassword(event.target.value);
	}

	function handleSubmit() {
		if (username === '' || password === '') {
			setErrorMsg('Fill in all fields');
		}
		const payload = { username, password }
		axios.post('/api/user/login', payload)
			.then(response => {
				if (response.data.error) {
					setErrorMsg(response.data.error);
				}
				else {
					setMsg('Successfully logged in, redirecting in 3 secs');
					const { username, userID } = response.data;
					window.localStorage.setItem('isLoggedIn', true);
					window.localStorage.setItem('username', username);
					window.localStorage.setItem('userID', userID);
					props.login();
					setUsername('');
					setPassword('');
					setErrorMsg('');
					setTimeout(() => history.push("/books"), 3000);
				}
				
			})
			.catch(error => console.log(error));
	}

	function successNotification() {
		return (
			<div className="alert alert-success text-center">
				{msg}
			</div>
		)
	}

	function failNotification() {
		return (
			<div className="alert alert-danger text-center">
				{errorMsg}
			</div>
		)
	}

	return (
		<>
			<div>
				<Link to="/">Home </Link>
			</div>
			<div className="row justify-content-center">
				<div className="card card-body py-5" style={{maxWidth: "500px"}}>
					<div className="form-group">
						<h3 className="text-center">Login</h3>
						{msg && successNotification()}
						{errorMsg && failNotification()}
						<label>Username: </label>
						<input type="email" value={username} onChange={(event) => handleUsernameChange(event)} className="form-control" placeholder="Username"/>
					</div>
					<div className="form-group">
						<label>Password</label>
						<input type="password" value={password} onChange={(event) => handlePasswordChange(event)} className="form-control" placeholder="Password"/>
					</div>
					<div className="text-right">
						<button className="btn btn-primary" onClick={() => handleSubmit()}>Submit</button>
						<Link to="/register" className="btn btn-secondary ml-2">Register</Link>
					</div>
				</div>
			</div>
		</>
	)
}

export default Login;