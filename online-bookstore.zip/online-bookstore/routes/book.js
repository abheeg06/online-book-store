const express = require('express');

const router = express.Router();

const Book = require('../schema/book');

router.get('/', (req, res) => {
	const { query } = req.query;
	if (query !== undefined) {
		const tags = query.split(" ");
		let q = [];
		tags.forEach(tag => {
			q.push({
				bookName: { $regex: tag }
			});
			q.push({
				author: { $regex: tag }
			})
		})
		Book.find({ $or: q }, (err, books) => {
			if (err) {
				res.json({ error: err});
			}

			else if (books.length === 0) {
				res.json({ error: 'No results'})
			}

			else res.json(books);
		})
	}
	else {
		Book.find({}, (err, books) => {
			if (err) {
				res.json({ error: err })
			}

			else {
				res.json(books);
			}
		})
	}
})

router.get('/category', (req, res) => {
	const { category } = req.query;
	Book.find({ category }, (err, books) => {
		if (err) {
			res.json({ error: err })
		}
		
		else {
			res.json(books);
		}
	})
})

router.get('/categories', (req, res) => {
	Book.distinct('category', (err, books) => {
		if (err) {
			res.json({ err })
		}

		res.json(books);
	});
})

router.get('/:book_id', (req, res) => {
  Book.findById(req.params.book_id, (err, book) => {
    if (err) {
      res.json({ error })
    }

    else {
      res.json(book);
    }
  })
})


module.exports = router;