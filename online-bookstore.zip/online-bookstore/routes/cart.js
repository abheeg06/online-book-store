const express = require('express');

const router = express.Router();

const Cart = require('../schema/cart');

router.get('/', (req, res) => {
  Cart.find({})
    .then((data) => {
      res.json(data);
    }).catch((error) => {
      console.log(error);
    })
})

router.patch('/add/:user_id', (req, res) => {
	const payload = req.body;
	if (Object.keys(payload).length !== 0 && payload.constructor !== Object) {
		const cartItems = payload.map(cartItem => ({ ...cartItem}))
		Cart.findOneAndUpdate({ userID: req.params.user_id }, { cartItems }, function(err, result) {
			if (err) {
				res.json({error: err});
			} else {
				res.json({result})
			}
		});
	}

	else if (Object.keys(payload).length === 0) {
		Cart.findOneAndUpdate({ userID: req.params.user_id }, { cartItems: [] }, function(err, result) {
			if (err) {
				res.json({error: err});
			}
			else {
				res.json([]);
			}
		})
	}
	else {
		res.json({error: 'no data'})
	}
})

router.delete('/delete/:user_id', (req, res) => {
	Cart.findOneAndUpdate({ userID: req.params.user_id }, { cartItems: [] }, function(err, result) {
		if (err) {
			res.json({error: err});
		}
		else {
			res.json({result: 'cart delete success'})
		}
	})
})

router.get('/:user_id', (req, res) => {
  Cart.findOne({ userID: req.params.user_id }, (err, cart) => {
    if (err) {
      res.json({ error })
    }

    else if (cart) {
      res.json(cart.cartItems);
    }

		else {
			res.json({error: 'no data'});
		}
  })
})


module.exports = router;