const express = require('express');

const router = express.Router();

const User = require('../schema/user');
const Cart = require('../schema/cart');

router.get('/', (req, res) => {
  User.find({})
    .then((data) => {
      res.json(data);
    }).catch((error) => {
      console.log(error);
    })
})

router.post('/register', (req, res) => {
	const { username, password } = req.body;
	User.findOne({ username }, (err, user) => {
		if (err) res.json({ error: err });
		if (user) {
			res.json({ error: 'Account already exists'})
		}

		else {
			const newUser = new User({ username, password });
			newUser.save((error, user) => {
				if (error) res.json({error});
				else if (user) {
					const newCart = new Cart({ userID: user._id, cartItems: []})
					newCart.save((error1, cart) => {
						if (error1) res.json({error: error1})
						else if (cart) {
							res.json({ username, userID: user._id})
						}
					})					
				}
			});
		}
	});
})

router.post('/login', (req, res) => {
	const { username, password } = req.body;
	User.findOne({ username }, (err, user) => {
		if (err) res.json({ error: err });
		if (user && user.password === password) {
			res.json({ username, userID: user._id });
		}
		else {
			res.json({ error: 'Invalid username or wrong password' })
		}
	})
})

router.get('/:user_id', (req, res) => {
  User.findById(req.params.user_id, (err, user) => {
    if (err) {
      res.json({ error })
    }

    else {
      res.json(user);
    }
  })
})


module.exports = router;