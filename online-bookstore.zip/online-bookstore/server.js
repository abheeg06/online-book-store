const express = require('express');
const mongoose = require('mongoose');
const morgan = require('morgan');

const app = express();
const PORT = 8080

const DATABASE_URI = 'mongodb+srv://admin:admin123@cluster-online-bookstor.nqnjq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority';
mongoose.set('useFindAndModify', false);

// Connect Database
mongoose.connect(DATABASE_URI, {
	useNewUrlParser: true,
	useUnifiedTopology: true
}, (err) => {
	if (err)
		console.log("MongoDB connection error: " + err);
	else
		console.log("Connected to MongoDB");
});

const userRoute = require('./routes/user');
const bookRoute = require('./routes/book');
const cartRoute = require('./routes/cart');

app.use(express.json());
app.use('/api/user', userRoute);
app.use('/api/book', bookRoute);
app.use('/api/cart', cartRoute);



app.use(express.json());
app.use(express.urlencoded({
	extended: false
}));


app.use(morgan('tiny'));
app.listen(PORT, console.log(`Server is starting at ${PORT}`));