const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const CartSchema = Schema({
	userID: String,
	cartItems: [{
		bookID: String,
		quantity: Number,
		bookName: String,
		price: Number
	}]
})

const Cart = mongoose.model('cart', CartSchema);

module.exports = Cart;