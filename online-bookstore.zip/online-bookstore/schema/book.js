const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const BookSchema = Schema({
	bookName: String,
	publisher: String,
	category: String,
	language: String,
	author: String,
	description: String,
	price: Number,
	published: String,
	newArrival: Boolean,
	imgPath: String
})

const Book = mongoose.model('book', BookSchema);

module.exports = Book;