================================ To Run App ===============================
1. in online-bookstore directory run "npm install" # installing node_modules for server.js
2. then "cd react-frontend && npm install" # installing node_modules for react-frontend
3. then run "npm start" in react-frontend directory in one terminal
4. then run "npm start" in online-bookstore directory in another terminal

Note: 
			mongodb database using mongodb cloud atlas because had issues in setting up local mongodb server,
			so connected with mongoose in server.js using srv link
			srv link: mongodb+srv://admin:admin123@cluster-online-bookstor.nqnjq.mongodb.net/myFirstDatabase?retryWrites=true&w=majority

================================== End ====================================

================================ Checklist ===============================
✔ Correctness of the login page (0.5 points)
✔ Correctness of the create account page (0.5 points)
✔ Correct functionality of verifying user’s login into the system (verifyLogin.php) (0.5 points)
✔ Correct functionality of users’ account creation (create.php) (0.5 points)
✔ Correct functionality of the main page (4 points)
✔ Correct functionality of the category page (0.5 points)
✔ Correct functionality of the book information page (0.5 points)
✔ Correct functionality of the cart page (4 points)
✔ Correct functionality of the checkout page (4 points)
✔ Correct functionality of the invoice page (0.5 points)
✔ Correct functionality of logout in “logout.php” (0.5 points)
✔ Correct implementation of responsive web features in web pages (2 points)
✔ CSS implementation in webpages (2 points)
================================== End ====================================

Version:
	express		: v4.17.1
	mongoose	: v5.12.6
  node			: v10.23.0
	mongo			: v4.4.5
	react			: v17.0.2